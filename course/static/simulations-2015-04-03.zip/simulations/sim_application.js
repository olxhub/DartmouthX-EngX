(function(){
angular.module('eau', [
  'ngMaterial',
  'eau.head-controller',
  'eau.navigation',
  'eau.simulation',
  'eau.simulation.compression',
  'eau.simulation.arch',
  'eau.simulation.tension'
])
.config(function($mdThemingProvider) {
  $mdThemingProvider.theme('default')
    .primaryPalette('grey')
    .accentPalette('blue')
    // .warnPallette('amber')
    ;
})
;

}).call(this);

(function() {
  var l10;

  l10 = Math.log(10);

  angular.module('eau.utilities.scientific', []).filter('scientific', function() {
    return function(number, digits) {
      var exponent, len, value;
      number = '' + number;
      len = number.length;
      exponent = number.length - 1;
      value = '' + number.charAt(0);
      if (digits) {
        value += '.' + number.substr(1, digits);
      }
      value += 'e' + exponent;
      return value;
    };
  });

}).call(this);

(function() {
  angular.module('eau.simulation.compression.materials', []).value('MaterialList', {
    "Concrete": {
      density: 23e3,
      elasticity: 20e6,
      stress: 70e3,
      color: 'bisque'
    },
    "Granite": {
      density: 27e3,
      elasticity: 80e6,
      stress: 150e3,
      color: 'slategrey'
    },
    "Plastic": {
      density: 27e3,
      elasticity: 2e6,
      stress: 50e3,
      color: 'honeydew'
    },
    "Glass": {
      density: 10e3,
      elasticity: 50e6,
      stress: 100e3,
      color: "paleturquoise"
    },
    "Steel": {
      density: 77e3,
      elasticity: 200e6,
      stress: 250e3,
      color: 'lightsteelblue'
    },
    "Wood": {
      density: 6e3,
      elasticity: 10e6,
      stress: 30e3,
      color: 'brown'
    },
    "Copper": {
      density: 87e3,
      elasticity: 100e6,
      stress: 150e3,
      color: "sienna"
    }
  }).value('MomentShapes', {
    "Square": {
      moment: function(b) {
        return Math.pow(b, 4) / 12;
      },
      crossSection: function(b) {
        return b * b;
      }
    },
    "Hollow Square": {
      moment: function(b) {
        var center, t, tube;
        t = b * .25;
        tube = Math.pow(b, 4);
        center = Math.pow(b - 2 * t, 4);
        return (tube - center) / 12;
      },
      crossSection: function(b) {
        var center, t, tube;
        t = b * .25;
        tube = b * b;
        center = Math.pow(b - 2 * t, 2);
        return tube - center;
      }
    },
    "Pipe": {
      moment: function(d) {
        return (Math.PI / 64) * Math.pow(d, 4);
      },
      crossSection: function(d) {
        return Math.PI * d * d * 1 / 4;
      }
    },
    "Hollow Pipe": {
      moment: function(d) {
        var center, pipe, t;
        t = d * .25;
        pipe = Math.pow(d, 4);
        center = Math.pow(d - 2 * t, 4);
        return (Math.PI / 64) * (pipe - center);
      },
      crossSection: function(d) {
        var center, pipe, t;
        t = d * .25;
        pipe = d * d;
        center = Math.pow(d - 2 * t, 2);
        return Math.PI * (pipe - center) * 1 / 4;
      }
    }
  });

}).call(this);

(function() {
  var Particle, SimulationFactory;

  Particle = (function() {
    function Particle(simulation, index) {
      this.simulation = simulation;
      this.index = index;
      Object.defineProperty(this, 'position', {
        get: function() {
          return [this.simulation.positions[this.index * 2], this.simulation.positions[this.index * 2 + 1]];
        }
      });
    }

    return Particle;

  })();

  SimulationFactory = function(WorkerSvc, $rootScope, $log) {
    var Simulation;
    Simulation = (function() {
      function Simulation(N, scripts1, generator) {
        var i;
        this.N = N;
        this.scripts = scripts1;
        this.generator = generator;
        this.dt = 16;
        this.running = false;
        this.worker = WorkerSvc.get('/simulation/verlet.coffee');
        this.worker.addEventListener('error', (function(e) {
          return $log.error(e);
        }));
        this.worker.addEventListener('message', (function(_this) {
          return function(arg) {
            var data, name;
            data = arg.data;
            return typeof _this[name = data.event] === "function" ? _this[name](data) : void 0;
          };
        })(this));
        this.positions = new Float64Array(this.N * 2);
        this.particles = (function() {
          var j, ref, results;
          results = [];
          for (i = j = 0, ref = this.N; 0 <= ref ? j < ref : j > ref; i = 0 <= ref ? ++j : --j) {
            results.push(new Particle(this, i));
          }
          return results;
        }).call(this);
        this.reset();
        scripts.forEach((function(_this) {
          return function(path) {
            return _this.worker.postMessage({
              event: 'load',
              url: WorkerSvc.getURL(path)
            });
          };
        })(this));
      }

      Simulation.prototype.reset = function() {
        var data, event;
        this.generator.call(this);
        data = new Float64Array(this.positions);
        event = {
          event: 'reset',
          count: data.length,
          dimensions: 2,
          positions: data.buffer
        };
        return this.worker.postMessage(event, [data.buffer]);
      };

      Simulation.prototype.tick = function() {
        return this.worker.postMessage({
          event: 'tick',
          dt: this.dt
        });
      };

      Simulation.prototype.render = function(arg) {
        var positions;
        positions = arg.positions;
        positions = new Float64Array(positions);
        return requestAnimationFrame((function(_this) {
          return function() {
            if (_this.running) {
              _this.tick();
            }
            return $rootScope.$apply(function() {
              var i, j, ref, results;
              results = [];
              for (i = j = 0, ref = _this.N; 0 <= ref ? j < ref : j > ref; i = 0 <= ref ? ++j : --j) {
                _this.positions[i * 2] = positions[i * 2];
                results.push(_this.positions[i * 2 + 1] = positions[i * 2 + 1]);
              }
              return results;
            });
          };
        })(this));
      };

      Simulation.prototype.run = function() {
        this.running = true;
        return this.tick();
      };

      Simulation.prototype.toggle = function() {
        if (this.running) {
          return this.running = false;
        } else {
          return this.run();
        }
      };

      return Simulation;

    })();
    return {
      build: function(a, b, c) {
        return new Simulation(a, b, c);
      }
    };
  };

  SimulationFactory.$inject = ['WorkerSvc', '$rootScope', '$log'];

  angular.module('eau.simulation.service', ['eau.workers']).factory('SimulationFactory', SimulationFactory);

}).call(this);

(function() {
  angular.module('eau.simulation.truss.shapes', []).value('Trusses', {
    Pratt: {
      flat: function(bays) {
        var beams, i, j, ref;
        if (bays == null) {
          bays = 2;
        }
        beams = [];
        beams.push([[0, 0], [0, 1]]);
        for (i = j = 0, ref = bays; 0 <= ref ? j < ref : j > ref; i = 0 <= ref ? ++j : --j) {
          beams.push([[i + 0, 1], [i + 1, 1]]);
          beams.push([[i + 1, 1], [i + 1, 0]]);
          beams.push([[i + 0, 0], [i + 1, 0]]);
          beams.push([[i + 0, 1], [i + 1, 0]]);
          beams.push([[-(i + 0), 1], [-(i + 1), 1]]);
          beams.push([[-(i + 1), 1], [-(i + 1), 0]]);
          beams.push([[-(i + 0), 0], [-(i + 1), 0]]);
          beams.push([[-(i + 0), 1], [-(i + 1), 0]]);
        }
        beams.push([[i + 0, 0], [i + 1, 0]]);
        beams.push([[i + 0, 1], [i + 1, 0]]);
        beams.push([[-(i + 0), 0], [-(i + 1), 0]]);
        beams.push([[-(i + 0), 1], [-(i + 1), 0]]);
        return beams;
      }
    },
    Howe: {
      flat: function(bays) {
        var beams, i, j, ref;
        if (bays == null) {
          bays = 2;
        }
        beams = [];
        beams.push([[0, 0], [0, 1]]);
        for (i = j = 0, ref = bays; 0 <= ref ? j < ref : j > ref; i = 0 <= ref ? ++j : --j) {
          beams.push([[i + 0, 1], [i + 1, 1]]);
          beams.push([[i + 1, 1], [i + 1, 0]]);
          beams.push([[i + 0, 0], [i + 1, 0]]);
          beams.push([[i + 0, 0], [i + 1, 1]]);
          beams.push([[-(i + 0), 1], [-(i + 1), 1]]);
          beams.push([[-(i + 1), 1], [-(i + 1), 0]]);
          beams.push([[-(i + 0), 0], [-(i + 1), 0]]);
          beams.push([[-(i + 0), 0], [-(i + 1), 1]]);
        }
        beams.push([[i + 0, 0], [i + 1, 0]]);
        beams.push([[i + 0, 1], [i + 1, 0]]);
        beams.push([[-(i + 0), 0], [-(i + 1), 0]]);
        beams.push([[-(i + 0), 1], [-(i + 1), 0]]);
        return beams;
      }
    }
  });

}).call(this);

(function() {
  angular.module('eau.title-service', []).service('TitleSvc', function() {
    return {
      title: 'Engineering Around Us'
    };
  });

}).call(this);

(function() {
  var WorkerSvc;

  WorkerSvc = (function() {
    function WorkerSvc(cache) {
      this.cache = cache;
      this.workers = {};
      this.URLs = {};
    }

    WorkerSvc.prototype.getURL = function(path) {
      var blob, logic;
      if (this.URLs[path] != null) {
        return this.URLs[path];
      }
      logic = this.cache.get(path);
      blob = new Blob([logic], {
        type: 'text/javascript'
      });
      return this.URLs[path] = window.URL.createObjectURL(blob);
    };

    WorkerSvc.prototype.get = function(path) {
      var code;
      if (this.workers[path] != null) {
        return this.workers[path];
      }
      code = this.getURL(path);
      return this.workers[path] = new Worker(code);
    };

    return WorkerSvc;

  })();

  WorkerSvc.$inject = ['$workerCache'];

  angular.module('workers', []);

  angular.module('eau.workers', ['workers']).factory('$workerCache', function($cacheFactory) {
    return $cacheFactory.get('workersCache');
  }).service('WorkerSvc', WorkerSvc);

}).call(this);

(function(){
angular.module('eau.head-controller', [
  'eau.title-service'
]).controller('HeadCtrl', function($scope, TitleSvc){
  $scope.title = TitleSvc.title;
});

}).call(this);

(function(){
var toRad = Math.PI / 180;
ArrowController.$inject = ['$scope'];
function ArrowController($scope){
  this.fill = this.fill || this.color;
  $scope.sin = function(thetaDeg){
    return Math.sin(thetaDeg * toRad);
  };
  $scope.cos = function(thetaDeg){
    return Math.cos(thetaDeg * toRad);
  };
}

angular.module('eau.arrow', [
  'arrow.template'
]).directive('arrow', function(){
  return {
    restrict: 'E',
    replace: true,
    templateNamespace: 'svg',
    templateUrl: 'arrow',
    controller: ArrowController,
    controllerAs: 'arrow',
    bindToController: true,
    scope: {
      tip: '=',
      length: '=',
      color: '=',
      rotation: '=',
      point: '=',
      fill: '@',
      weight: '@'
    }
  };
});

}).call(this);

(function() {
  var NavigationCtrl, SimulationNav;

  SimulationNav = function($stateProvider) {
    var simlist;
    simlist = [];
    return {
      sim: function(name, args) {
        if (arguments.length === 1) {
          args = name;
        } else {
          args.name = name;
        }
        if (!args.templateUrl) {
          args.template || (args.template = "<" + args.name + " />");
        }
        simlist.push(args);
        return $stateProvider.state(args.name, {
          url: "/" + args.name,
          views: {
            "simulation": args
          }
        });
      },
      $get: function() {
        return simlist;
      }
    };
  };

  SimulationNav.$inject = ['$stateProvider'];

  NavigationCtrl = function(sims) {
    this.sims = sims;
  };

  NavigationCtrl.$inject = ['SimulationNav'];

  angular.module('eau.navigation', ['ui.router', 'navigation.template']).provider('SimulationNav', SimulationNav).controller('NavigationCtrl', NavigationCtrl).directive('navigation', function() {
    return {
      restrict: 'E',
      templateUrl: 'navigation',
      controller: 'NavigationCtrl',
      controllerAs: 'nav'
    };
  });

}).call(this);

(function() {
  angular.module('eau.simulation.arch', ['eau.navigation', 'eau.arrow', 'simulation.arch.template']).config([
    'SimulationNavProvider', function(sims) {
      return sims.sim('arch', {
        title: 'Arch'
      });
    }
  ]).directive('arch', function() {
    return {
      restrict: 'E',
      templateUrl: 'simulation/arch',
      controller: function($scope) {
        $scope.simulation = {
          applied: 25,
          height: 200,
          span: 200
        };
        $scope.forall = function(n) {
          var i, results;
          return (function() {
            results = [];
            for (var i = 0; 0 <= n ? i < n : i > n; 0 <= n ? i++ : i--){ results.push(i); }
            return results;
          }).apply(this);
        };
        $scope.force = {
          vertical: function() {
            var L, v, w;
            w = $scope.simulation.applied;
            L = $scope.simulation.span;
            v = w * (L / 2);
            return Math.round(v);
          },
          horizontal: function() {
            var L, d, d8, h, w;
            d = $scope.simulation.height;
            d8 = d * 8;
            L = $scope.simulation.span;
            w = $scope.simulation.applied;
            h = w * L * L / d8;
            return Math.round(h);
          },
          compressive: function() {
            return $scope.force.horizontal();
          }
        };
        $scope.force.vertical.max = 75000;
        return $scope.force.horizontal.max = 1125000;
      }
    };
  });

}).call(this);

(function() {
  angular.module('eau.simulation.arch.brick', ['simulation.arch.brick.template']).directive('brick', function() {
    return {
      restrict: 'E',
      replace: true,
      templateUrl: 'simulation/arch/brick',
      templateNamespace: 'svg'
    };
  });

}).call(this);

(function() {
  var GRAVITY, PI_SQUARED;

  PI_SQUARED = Math.PI * Math.PI;

  GRAVITY = 9.81;

  angular.module('eau.simulation.compression', ['eau.simulation.compression.materials', 'simulation.compression.template', 'eau.utilities.scientific', 'graphing.scales', 'graphing.svg', 'ngMaterial', 'eau.navigation']).config([
    'SimulationNavProvider', function(sims) {
      return sims.sim('compression', {
        title: 'Column Compression'
      });
    }
  ]).directive('compression', function() {
    return {
      restrict: 'E',
      templateUrl: 'simulation/compression',
      controller: function($scope, MaterialList, MomentShapes) {
        var s, setCurrentMaterial, setCurrentShape;
        $scope.setCurrentMaterial = setCurrentMaterial = function(materialName) {
          if (MaterialList[materialName] == null) {
            return;
          }
          $scope.materialName = materialName;
          return $scope.currentMaterial = {
            material: materialName,
            density: MaterialList[materialName].density,
            elasticity: MaterialList[materialName].elasticity,
            color: MaterialList[materialName].color,
            stress: MaterialList[materialName].stress
          };
        };
        $scope.setCurrentShape = setCurrentShape = function(shape) {
          if (MomentShapes[shape] == null) {
            return;
          }
          $scope.shapeName = shape;
          return $scope.currentShape = {
            shape: shape,
            description: MomentShapes[shape].description || shape,
            moment: MomentShapes[shape].moment,
            crossSection: MomentShapes[shape].crossSection
          };
        };
        $scope.materials = Object.keys(MaterialList);
        $scope.shapes = Object.keys(MomentShapes);
        setCurrentMaterial('Steel');
        setCurrentShape('Square');
        $scope.$watch('materialName', function(newMaterial) {
          $scope.resetLoad();
          return setCurrentMaterial(newMaterial);
        });
        $scope.$watch('shapeName', function(newShape) {
          $scope.resetLoad();
          return setCurrentShape(newShape);
        });
        s = $scope.simulation = {
          applied: 0,
          length: 2,
          base: .25
        };
        $scope.simulation.crossSection = function() {
          var ba;
          ba = parseFloat(s.base);
          return $scope.currentShape.crossSection(ba);
        };
        $scope.simulation.moment = function() {
          return $scope.currentShape.moment($scope.simulation.base);
        };
        $scope.simulation.buckle = function() {
          var ba, buckle, e, l, moment;
          ba = $scope.simulation.crossSection();
          l = parseFloat(s.length);
          e = $scope.currentMaterial.elasticity;
          moment = $scope.simulation.moment();
          buckle = PI_SQUARED * e * moment / (l * l);
          return Math.round(buckle);
        };
        $scope.simulation.compression = function() {
          var area, stress;
          stress = $scope.currentMaterial.stress;
          area = $scope.simulation.crossSection();
          return Math.round(stress * area);
        };
        $scope.simulation.deflection = function(n) {
          if ($scope.simulation.compression() < $scope.simulation.buckle()) {
            return 0;
          }
          if (s.failed()) {
            return parseFloat(s.base);
          } else {
            return 0;
          }
        };
        $scope.simulation.failure = function() {
          return Math.min($scope.simulation.compression(), $scope.simulation.buckle());
        };
        $scope.simulation.failed = function() {
          return s.applied >= s.buckle() || s.applied >= s.compression();
        };
        $scope.showLoad = false;
        $scope.resetLoad = function() {
          $scope.showLoad = false;
          return $scope.simulation.applied = 1;
        };
        $scope.$watch('simulation.length', function() {
          return $scope.resetLoad();
        });
        $scope.$watch('simulation.base', function() {
          return $scope.resetLoad();
        });
        return $scope.calcLoad = function() {
          $scope.simulation.applied = $scope.simulation.failure();
          return $scope.showLoad = true;
        };
      }
    };
  });

}).call(this);

(function() {
  angular.module('eau.simulation.nbody', ['eau.simulation.service', 'simulation.template', 'eau.simulation.arch', 'graphing.scales', 'graphing.svg']).config([
    'SimulationNavProvider', function(sims) {
      return sims.sim('nbody', {
        title: 'N-Body Gravity + Collisions'
      });
    }
  ]).directive('nbody', function() {
    return {
      restrict: 'E',
      templateUrl: 'simulation',
      controller: function($scope, SimulationFactory) {
        return $scope.simulation = SimulationFactory.build(20, ['/simulation/nbody/nbody.coffee'], function() {
          var i, j, ref, results;
          results = [];
          for (i = j = 0, ref = this.N; 0 <= ref ? j < ref : j > ref; i = 0 <= ref ? ++j : --j) {
            this.positions[i * 2] = Math.random();
            results.push(this.positions[i * 2 + 1] = Math.random());
          }
          return results;
        });
      }
    };
  });

}).call(this);

(function() {
  angular.module('eau.simulation', ['eau.simulation.service', 'simulation.template', 'eau.simulation.arch', 'graphing.scales', 'graphing.svg']).config([
    'SimulationNavProvider', function(sims) {
      return sims.sim('falling', {
        title: 'Falling'
      });
    }
  ]).directive('falling', function() {
    return {
      restrict: 'E',
      templateUrl: 'simulation',
      controller: function($scope, SimulationFactory) {
        return $scope.simulation = SimulationFactory.build(10, ['/simulation/constraints/ground.coffee', '/simulation/forces/gravity.coffee', '/simulation/forces/bounce.coffee'], function() {
          var i, j, ref, results;
          results = [];
          for (i = j = 0, ref = this.N; 0 <= ref ? j < ref : j > ref; i = 0 <= ref ? ++j : --j) {
            this.positions[i * 2] = Math.random();
            results.push(this.positions[i * 2 + 1] = Math.random());
          }
          return results;
        });
      }
    };
  });

}).call(this);

(function() {
  angular.module('eau.simulation.spring', ['eau.simulation.service', 'simulation.template', 'eau.simulation.arch', 'graphing.scales', 'graphing.svg']).config([
    'SimulationNavProvider', function(sims) {
      return sims.sim('spring', {
        title: 'Brick on a Spring'
      });
    }
  ]).directive('spring', function() {
    return {
      restrict: 'E',
      templateUrl: 'simulation',
      controller: function($scope, SimulationFactory) {
        return $scope.simulation = SimulationFactory.build(2, ['/simulation/spring/spring.coffee'], function() {
          var event, i, j, ref, springList;
          for (i = j = 0, ref = this.N; 0 <= ref ? j < ref : j > ref; i = 0 <= ref ? ++j : --j) {
            this.positions[i * 2] = Math.random();
            this.positions[i * 2 + 1] = Math.random();
          }
          springList = {};
          event = {
            event: 'setSprings'
          };
          return this.worker.postMessage(event);
        });
      }
    };
  });

}).call(this);

(function() {
  angular.module('eau.simulation.tension', ['simulation.tension.template', 'eau.utilities.scientific', 'eau.arrow', 'graphing.scales', 'graphing.svg', 'ngMaterial', 'eau.navigation']).config([
    'SimulationNavProvider', function(sims) {
      return sims.sim('tension', {
        title: 'Funicular Tension'
      });
    }
  ]).directive('tension', function() {
    return {
      restrict: 'E',
      templateUrl: 'simulation/tension',
      controller: function($scope) {
        $scope.materials = [
          {
            name: 'Steel',
            maxStress: 250e6
          }, {
            name: 'Nylon',
            maxStress: 50e6
          }
        ];
        $scope.simulation = {
          width: 4,
          pull: 2,
          diameter: 10,
          material: $scope.materials[0]
        };
        $scope.area = function() {
          var d, d2;
          d = $scope.simulation.diameter;
          d2 = d / 2;
          return Math.PI * d2 * d2;
        };
        $scope.theta = function() {
          var s;
          s = $scope.simulation;
          return Math.atan(s.pull / (s.width / 2));
        };
        $scope.thetaDeg = function() {
          return $scope.theta() * 180 / Math.PI;
        };
        $scope.simulation.stress = function() {
          var a, m;
          a = $scope.area() / 1000;
          m = $scope.simulation.material;
          return m.maxStress * a;
        };
        $scope.simulation.load = function() {
          var s;
          s = Math.sin($scope.theta());
          return 2 * s * $scope.simulation.stress();
        };
        return $scope.showLoad = false;
      }
    };
  });

}).call(this);

(function() {
  angular.module('eau.simulation.truss', ['eau.simulation.truss.shapes', 'simulation.truss.template', 'eau.utilities.scientific', 'graphing.scales', 'graphing.svg', 'ngMaterial']).config([
    'SimulationNavProvider', function(sims) {
      return sims.sim('truss', {
        title: 'Truss'
      });
    }
  ]).directive('truss', function() {
    return {
      restrict: 'E',
      templateUrl: 'simulation/truss',
      controller: function($scope, Trusses, $mdDialog) {
        return $scope.truss = Trusses.Howe.flat($scope.beams);
      }
    };
  });

}).call(this);
